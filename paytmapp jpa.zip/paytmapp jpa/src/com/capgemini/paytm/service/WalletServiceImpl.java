package com.capgemini.paytm.service;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.paytm.beans.Customer;
import com.capgemini.paytm.beans.Wallet;
import com.capgemini.paytm.exception.InsufficientBalanceException;
import com.capgemini.paytm.exception.InvalidInputException;
import com.capgemini.paytm.repo.WalletRepo;
import com.capgemini.paytm.repo.WalletRepoImpl;
import com.capgemini.paytm.ui.Client;

public class WalletServiceImpl implements WalletService {

	private WalletRepo repo;

	public WalletServiceImpl(WalletRepo repo) {
		super();
		this.repo = repo;
	}

	public WalletServiceImpl() {
		repo = new WalletRepoImpl();
	}

	public boolean validatephone(String phoneno) {

		String pattern1 = "[7-9]?[0-9]{10}";
		if (phoneno.matches(pattern1)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean validateName(String pName) {
		String pattern = "[A-Z][a-zA-Z]*";
		if (pName.matches(pattern)) {
			return true;
		} else {
			return false;
		}
	}

	WalletRepoImpl obj = new WalletRepoImpl();

	public Customer createAccount(String name, String mobileNo,
			BigDecimal amount) throws Exception {
		int id = (int) (Math.random() * 100);
		Wallet wallet = new Wallet(amount, id);
		Customer cust = new Customer(name, mobileNo, new Wallet(amount, id));
		acceptCustomerDetails(cust);
		boolean result = repo.save(cust);
		if (result == true)
			return cust;
		else
			return null;

	}

	public Customer showBalance(String mobileNo) throws SQLException {

		Customer customer = repo.findOne(mobileNo);
		if (customer != null)
			return customer;
		else
			throw new InvalidInputException("Invalid mobile no ");
	}

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo,
			BigDecimal amount) throws InvalidInputException, SQLException {

		Customer sourceCustomer = repo.findOne(sourceMobileNo);
		//System.out.println(sourceCustomer);
		Customer targetCustomer = repo.findOne(targetMobileNo);
		//System.out.println(targetCustomer);
		if ((sourceCustomer != null) && (targetCustomer != null)) {
			Customer scust = withdrawAmount(sourceMobileNo, amount);
			System.out.println(scust);
			Customer tcust = depositAmount(targetMobileNo, amount);
			System.out.println(tcust);
			
			return scust;
		} else
			return null;

	}

	public Customer depositAmount(String mobileNo, BigDecimal amount)
			throws InvalidInputException, SQLException {
		//System.out.println("depositing into the target");
		Customer cust = repo.findOne(mobileNo);
		//System.out.println(cust);
		try {
			if (cust != null) {
				Wallet iAmount = cust.getWallet();
				BigDecimal updatedBalance = iAmount.getBalance().add(amount);
				int id = cust.getWallet().getWalletid();
			//System.out.println(updatedBalance);
				Wallet wallet = new Wallet(updatedBalance, id);
				cust.setWallet(wallet);
				repo.update(cust);
				return cust;
			}
		} catch (InvalidInputException e) {
			System.err.println("invalid details");

		}
		return cust;
	
	}

	public Customer withdrawAmount(String mobileNo, BigDecimal amount)
			throws SQLException {
		//System.out.println("withdrawing from the source customer");
		Customer cust = repo.findOne(mobileNo);
		try {
			
			if (cust != null) {
				
				Wallet iAmount = cust.getWallet();
				BigDecimal updatedBalance = iAmount.getBalance().subtract(
						amount);
			//System.out.println(updatedBalance);
				int id = cust.getWallet().getWalletid();
				Wallet wallet = new Wallet(updatedBalance, id);
				//System.out.println(wallet);
				cust.setWallet(wallet);
				repo.update(cust);
				return cust;
			} 

		} catch (SQLException e) {
			System.err.println("invalid details");}

	
		return cust;
	}

	public void acceptCustomerDetails(Customer cust) {
		Scanner sc = new Scanner(System.in);
		while (true) {
			String str = cust.getMobileNo();
			if (validatephone(str))// method validate name
			{

				break;
			} else {
				System.err
						.println("Wrong Phone number!!\n Please Start with 9 ");
				System.out.println("Enter Phone number Again eg:9876543210");
				cust.setMobileNo(sc.next());
			}
		}
		while (true) {
			String str1 = cust.getName();
			if (validateName(str1))// method validate name
			{
				break;
			} else {
				System.err.println("Wrong  Name!!\n Please Start with Capital letter ");
				System.out.println("Enter  Name Again eg:Name");
				cust.setName(sc.next());
			}
		}
	}

}
