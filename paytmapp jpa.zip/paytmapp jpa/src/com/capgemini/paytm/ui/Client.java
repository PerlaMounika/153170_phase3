package com.capgemini.paytm.ui;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.paytm.beans.Customer;
import com.capgemini.paytm.beans.Wallet;
import com.capgemini.paytm.service.WalletService;
import com.capgemini.paytm.service.WalletServiceImpl;

public class Client {

	public static void main(String[] args) throws SQLException, Exception {

		WalletService walletService;
		{
			walletService = new WalletServiceImpl();
		}

		String ans;
		Scanner sc = new Scanner(System.in);
		System.out.println("****Paytm Application****");
		// Customer customer=new Customer()
		// c;programfiles:connectorj5.1

		do {
			System.out.println("1. Create Account ");
			System.out.println("2. Show Balance");
			System.out.println("3. Fund Transfer");
			System.out.println("4. Deposit amount");
			System.out.println("5. Withdraw amount");
			System.out.println("6. Exit");
			System.out.println("\nPlease Select an option:");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter Name: ");
				String name = sc.next();
				System.out.println("Enter Mobile Number: ");
				String mobileNo = sc.next();
				System.out.println("Enter Balance");
				BigDecimal amount = sc.nextBigDecimal();
				//System.out.println("enter into the service layer");
				Customer customer1 = walletService.createAccount(name,
						mobileNo, amount);
				//System.out.println(customer1);
				if (customer1 != null) {
					System.out.println("Your account is successfully created!");
					System.out.println(LocalDate.now());
					System.out.println(customer1);
				} else {
					System.out
							.println("Account Already Exist,Plz Change mobileno");
				}
				break;
			case 2:
				System.out.println("Enter the mobile number to view balance: ");
				String mobileNo2 = sc.next();
				Customer customer2 = walletService.showBalance(mobileNo2);
				System.out.println(LocalDate.now());
				System.out.println(customer2);
				break;
			case 3:
				System.out.println("Enter Source Mobile Number: ");
				String sourceMobileNo = sc.next();
				System.out.println("Enter Target Mobile Number: ");
				String targetMobileNo = sc.next();
				System.out.println("Enter amount to transfer");
				BigDecimal amount1 = sc.nextBigDecimal();
				Customer customer3 = walletService.fundTransfer(sourceMobileNo,
						targetMobileNo, amount1);
				System.out.println(LocalDate.now());
				System.out.println(customer3);
				break;
			case 4:
				System.out.println("Enter Mobile Number: ");
				String mobileNo3 = sc.next();
				System.out.println("Enter amount to deposit");
				BigDecimal amount3 = sc.nextBigDecimal();
				Customer customer4 = walletService.depositAmount(mobileNo3,amount3);
				System.out.println(LocalDate.now());
				System.out.println(customer4);
				break;
			case 5:
				System.out.println("Enter Mobile Number: ");
				String mobileNo4 = sc.next();
				System.out.println("Enter amount to withdraw");
				BigDecimal amount4 = sc.nextBigDecimal();
				Customer customer5 = walletService.withdrawAmount(mobileNo4,amount4);
				System.out.println(LocalDate.now());
				System.out.println(customer5);
				break;
			case 6:
				System.out.println("Thank You");
				System.exit(0);
				break;
			default:
				System.out.println("Invalid options");
				break;
			}
			System.out.println("\nDo you want to continue: Y/N ");
			ans = sc.next();
		} while (ans.equals("y") || ans.equals("yes"));
		System.out.println("\nThank you for using this service!");
	}

}
