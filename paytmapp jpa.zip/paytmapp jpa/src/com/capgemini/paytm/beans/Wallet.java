package com.capgemini.paytm.beans;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Wallet {

	private BigDecimal balance;
	@Id
	int walletid;

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public int getWalletid() {
		return walletid;
	}

	public void setWalletid(int walletid) {
		this.walletid = walletid;
	}

	public Wallet(BigDecimal balance, int walletid) {
		super();
		this.balance = balance;
		this.walletid = walletid;
	}

	public Wallet() {
		super();
	}
	@Override
	public String toString() {
		return "\tbalance=" + balance + ", walletid=" + walletid;
	}

	public Wallet(BigDecimal balance) {
		super();
		this.balance = balance;
	}

}
