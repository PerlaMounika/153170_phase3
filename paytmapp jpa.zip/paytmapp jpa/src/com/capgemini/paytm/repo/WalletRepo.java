package com.capgemini.paytm.repo;

import java.sql.SQLException;

import com.capgemini.paytm.beans.Customer;

public interface WalletRepo {

	public boolean save(Customer customer)throws Exception ;	
	public Customer findOne(String mobileNo) throws SQLException;
	public void update(Customer customer) throws SQLException;
}
